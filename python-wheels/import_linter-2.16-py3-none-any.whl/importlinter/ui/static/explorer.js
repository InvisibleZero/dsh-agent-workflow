let svg = null;
let viewBox = { x: 0, y: 0, width: 0, height: 0 };
let originalViewBox = null;
let isPanning = false;
let startPoint = { x: 0, y: 0 };
let scale = 1;

// Navigation state
let currentModule = null;
let navigationHistory = [];
let vizInstance = null;
let currentPackages = [];

// The modules being explored. When more than one is supplied, an empty module ("") is the
// top-level overview showing those modules and the dependencies between them.
const overviewModules = window.__OVERVIEW_MODULES__ || [];
const isMultiRoot = overviewModules.length > 1;
const OVERVIEW_LABEL = 'multiple packages';

// Settings state
let showImportTotals = false;
let showModuleCounts = false;
let showLazyImports = false;
let showCycleBreakers = false;

// Client-side cache for rendered graphs
const graphCache = new Map();

async function initViz() {
    vizInstance = await Viz.instance();
}

function buildApiUrl(moduleName) {
    let url = moduleName ? `/api/graph/${encodeURIComponent(moduleName)}` : '/api/graph';
    const params = [];
    if (showImportTotals) {
        params.push('show_import_totals=true');
    }
    if (showModuleCounts) {
        params.push('show_module_counts=true');
    }
    if (showLazyImports) {
        params.push('show_lazy_imports=true');
    }
    if (showCycleBreakers) {
        params.push('show_cycle_breakers=true');
    }
    if (params.length) {
        url += '?' + params.join('&');
    }
    return url;
}

function buildCacheKey(moduleName) {
    return `${moduleName}|${showImportTotals}|${showModuleCounts}|${showLazyImports}|${showCycleBreakers}`;
}

function onSettingsChange() {
    showImportTotals = document.getElementById('toggle-import-totals').checked;
    showModuleCounts = document.getElementById('toggle-module-counts').checked;
    showLazyImports = document.getElementById('toggle-lazy-imports').checked;
    showCycleBreakers = document.getElementById('toggle-cycle-breakers').checked;
    loadGraph(currentModule, false);
}

async function loadGraph(moduleName = null, updateHistory = true) {
    const loading = document.getElementById('loading');
    const errorMsg = document.getElementById('error-message');

    // Check cache first
    if (moduleName) {
        const cacheKey = buildCacheKey(moduleName);
        if (graphCache.has(cacheKey)) {
            const cached = graphCache.get(cacheKey);
            restoreFromCache(cached, updateHistory);
            return;
        }
    }

    loading.style.display = 'flex';
    errorMsg.style.display = 'none';

    try {
        const url = buildApiUrl(moduleName);
        const response = await fetch(url);
        const data = await response.json();

        if (data.error) {
            throw new Error(data.error);
        }

        currentModule = data.module;
        currentPackages = data.child_packages || [];
        updateBreadcrumb();

        if (updateHistory) {
            updateUrl(currentModule);
        }

        let dot = data.dot_string;

        // Render DOT to SVG using viz.js
        if (!vizInstance) {
            await initViz();
        }
        const svgElement = vizInstance.renderSVGElement(dot);

        // Insert SVG into container
        const container = document.getElementById('graph-svg');
        container.innerHTML = '';
        container.appendChild(svgElement);

        svg = container.querySelector('svg');
        loading.style.display = 'none';

        // Setup viewBox for pan/zoom
        const bbox = svg.getBBox();
        const padding = 20;
        viewBox = {
            x: bbox.x - padding,
            y: bbox.y - padding,
            width: bbox.width + padding * 2,
            height: bbox.height + padding * 2
        };
        originalViewBox = { ...viewBox };
        updateViewBox();

        // Setup event handlers
        setupPanZoom();
        setupNodeClicks();

        // Cache the rendered graph
        const cacheKey = buildCacheKey(currentModule);
        graphCache.set(cacheKey, {
            module: currentModule,
            packages: currentPackages,
            svgElement: svgElement.cloneNode(true),
            viewBox: { ...originalViewBox }
        });

    } catch (error) {
        loading.style.display = 'none';
        errorMsg.textContent = `Failed to load graph: ${error.message}`;
        errorMsg.style.display = 'block';
    }
}

function restoreFromCache(cached, updateHistory) {
    currentModule = cached.module;
    currentPackages = [...cached.packages];
    updateBreadcrumb();

    if (updateHistory) {
        updateUrl(currentModule);
    }

    const container = document.getElementById('graph-svg');
    container.innerHTML = '';
    container.appendChild(cached.svgElement.cloneNode(true));

    svg = container.querySelector('svg');

    viewBox = { ...cached.viewBox };
    originalViewBox = { ...cached.viewBox };
    updateViewBox();

    setupPanZoom();
    setupNodeClicks();
}

// Return the supplied overview module that moduleName is equal to, or a descendant of, or null if
// there is none. When overview modules are nested, the longest (most specific) match wins.
function overviewModuleFor(moduleName) {
    let match = null;
    for (const m of overviewModules) {
        if (moduleName === m || moduleName.startsWith(m + '.')) {
            if (match === null || m.length > match.length) {
                match = m;
            }
        }
    }
    return match;
}

// Append one crumb per namespace component of dotted (e.g. "utils.translation"), each linking to
// its full path under prefix. An empty dotted string appends nothing.
function appendDottedCrumbs(crumbs, prefix, dotted) {
    if (!dotted) return;
    const parts = dotted.split('.');
    for (let i = 0; i < parts.length; i++) {
        const sub = parts.slice(0, i + 1).join('.');
        crumbs.push({ label: parts[i], path: prefix ? `${prefix}.${sub}` : sub });
    }
}

// Build the list of {label, path} crumbs for the current module. The last crumb is the current
// location; the rest are clickable ancestors.
function buildCrumbs() {
    const crumbs = [];

    if (isMultiRoot) {
        // Every module hangs off the overview.
        crumbs.push({ label: OVERVIEW_LABEL, path: '' });
        // A supplied module is shown as a single crumb rather than split into its namespace
        // components: its parents weren't requested and aren't navigable. Only drill-down below
        // the supplied module is broken out into further crumbs.
        const base = overviewModuleFor(currentModule);
        if (base !== null) {
            crumbs.push({ label: base, path: base });
            appendDottedCrumbs(crumbs, base, currentModule.slice(base.length + 1));
            return crumbs;
        }
    }

    // Single module (or a module outside the supplied set): show the full namespace path.
    appendDottedCrumbs(crumbs, '', currentModule);
    return crumbs;
}

function updateBreadcrumb() {
    const breadcrumb = document.getElementById('breadcrumb');
    let html = '<span class="prefix">Import graph for</span>';

    if (isMultiRoot && currentModule === '') {
        html += `<span class="current">${OVERVIEW_LABEL}</span>`;
        breadcrumb.innerHTML = html;
        document.getElementById('nav-section').style.display = 'none';
        return;
    }

    const crumbs = buildCrumbs();
    crumbs.forEach((crumb, i) => {
        if (i === crumbs.length - 1) {
            html += `<span class="current">${crumb.label}</span>`;
        } else {
            html += `<span class="crumb" onclick="navigateTo('${crumb.path}')">${crumb.label}</span>`;
            html += '<span class="separator">/</span>';
        }
    });

    breadcrumb.innerHTML = html;

    const navSection = document.getElementById('nav-section');
    // We can go up whenever there's an ancestor crumb to go up to.
    navSection.style.display = crumbs.length > 1 ? 'flex' : 'none';
}

function goUp() {
    if (isMultiRoot) {
        const base = overviewModuleFor(currentModule);
        if (base === null || currentModule === base) {
            // At a supplied module (or outside the set): the only way up is the overview.
            if (currentModule !== '') {
                navigationHistory.push(currentModule);
                loadGraph('');
            }
            return;
        }
        // Below a supplied module: go up one namespace level (never past the supplied module).
        const parentModule = currentModule.split('.').slice(0, -1).join('.');
        navigationHistory.push(currentModule);
        loadGraph(parentModule);
        return;
    }

    const parts = currentModule.split('.');
    if (parts.length <= 1) {
        return;
    }
    const parentModule = parts.slice(0, -1).join('.');
    navigationHistory.push(currentModule);
    loadGraph(parentModule);
}

function navigateTo(moduleName) {
    if (moduleName === currentModule) return;
    navigationHistory.push(currentModule);
    loadGraph(moduleName);
}

function drillDown(relativeNodeName) {
    const childName = relativeNodeName.startsWith('.') ? relativeNodeName.slice(1) : relativeNodeName;
    // From the overview ("") the child is a root package, with no prefix to prepend.
    const fullModuleName = currentModule ? `${currentModule}.${childName}` : childName;
    navigationHistory.push(currentModule);
    loadGraph(fullModuleName);
}

function updateViewBox() {
    if (svg) {
        svg.setAttribute('viewBox', `${viewBox.x} ${viewBox.y} ${viewBox.width} ${viewBox.height}`);
    }
}

function setupPanZoom() {
    const container = document.getElementById('graph-container');

    // Remove existing listeners by cloning
    const newContainer = container.cloneNode(true);
    container.parentNode.replaceChild(newContainer, container);

    // Re-get references after clone
    svg = document.querySelector('#graph-svg svg');

    const graphContainer = document.getElementById('graph-container');

    graphContainer.addEventListener('mousedown', (e) => {
        if (e.button === 0 && e.target.closest('#graph-svg')) {
            isPanning = true;
            startPoint = { x: e.clientX, y: e.clientY };
            graphContainer.style.cursor = 'grabbing';
        }
    });

    graphContainer.addEventListener('mousemove', (e) => {
        if (!isPanning) return;

        const dx = (e.clientX - startPoint.x) * (viewBox.width / graphContainer.clientWidth);
        const dy = (e.clientY - startPoint.y) * (viewBox.height / graphContainer.clientHeight);

        viewBox.x -= dx;
        viewBox.y -= dy;

        startPoint = { x: e.clientX, y: e.clientY };
        updateViewBox();
    });

    graphContainer.addEventListener('mouseup', () => {
        isPanning = false;
        graphContainer.style.cursor = 'grab';
    });

    graphContainer.addEventListener('mouseleave', () => {
        isPanning = false;
        graphContainer.style.cursor = 'grab';
    });

    graphContainer.addEventListener('wheel', (e) => {
        if (!e.target.closest('#graph-svg')) return;
        e.preventDefault();

        const zoomFactor = e.deltaY > 0 ? 1.1 : 0.9;
        zoom(zoomFactor, e.clientX, e.clientY);
    }, { passive: false });
}

function zoom(factor, clientX, clientY) {
    const container = document.getElementById('graph-container');
    const rect = container.getBoundingClientRect();

    const mouseX = viewBox.x + (clientX - rect.left) / rect.width * viewBox.width;
    const mouseY = viewBox.y + (clientY - rect.top) / rect.height * viewBox.height;

    const newWidth = viewBox.width * factor;
    const newHeight = viewBox.height * factor;

    viewBox.x = mouseX - (mouseX - viewBox.x) * factor;
    viewBox.y = mouseY - (mouseY - viewBox.y) * factor;
    viewBox.width = newWidth;
    viewBox.height = newHeight;

    scale /= factor;
    updateViewBox();
}

function zoomIn() {
    const container = document.getElementById('graph-container');
    const rect = container.getBoundingClientRect();
    zoom(0.8, rect.left + rect.width / 2, rect.top + rect.height / 2);
}

function zoomOut() {
    const container = document.getElementById('graph-container');
    const rect = container.getBoundingClientRect();
    zoom(1.25, rect.left + rect.width / 2, rect.top + rect.height / 2);
}

function resetView() {
    if (originalViewBox) {
        viewBox = { ...originalViewBox };
        scale = 1;
        updateViewBox();
    }
}

function setupNodeClicks() {
    if (!svg) return;

    const tooltip = document.getElementById('tooltip');
    const nodes = svg.querySelectorAll('.node');

    nodes.forEach(node => {
        const title = node.querySelector('title');
        const nodeName = title ? title.textContent : 'Unknown';
        const isPackage = currentPackages.includes(nodeName);

        if (isPackage) {
            node.classList.add('package');

            node.addEventListener('click', (e) => {
                e.stopPropagation();
                e.stopImmediatePropagation();
                e.preventDefault();
                if (node.dataset.clicking) return;
                node.dataset.clicking = 'true';
                setTimeout(() => delete node.dataset.clicking, 500);
                tooltip.style.display = 'none';
                drillDown(nodeName);
            });

            node.addEventListener('mouseenter', (e) => {
                const childName = nodeName.startsWith('.') ? nodeName.slice(1) : nodeName;
                const target = currentModule ? `${currentModule}.${childName}` : childName;
                tooltip.textContent = `Explore ${target}`;
                tooltip.style.display = 'block';
            });

            node.addEventListener('mousemove', (e) => {
                tooltip.style.left = (e.clientX + 10) + 'px';
                tooltip.style.top = (e.clientY + 10) + 'px';
            });

            node.addEventListener('mouseleave', () => {
                tooltip.style.display = 'none';
            });
        }
    });
}

function updateUrl(moduleName) {
    const url = new URL(window.location);
    if (moduleName) {
        url.searchParams.set('module', moduleName);
    } else {
        url.searchParams.delete('module');
    }
    history.pushState({ module: moduleName }, '', url);
}

function getModuleFromUrl() {
    const params = new URLSearchParams(window.location.search);
    return params.get('module');
}

// Handle browser back/forward
window.addEventListener('popstate', (event) => {
    const module = event.state?.module || getModuleFromUrl();
    loadGraph(module, false);
});

// Load graph on page load
initViz().then(() => {
    const moduleFromUrl = getModuleFromUrl();
    const initialModule = moduleFromUrl !== null ? moduleFromUrl : (window.__INITIAL_MODULE__ || '');
    loadGraph(initialModule, false);
    history.replaceState({ module: initialModule }, '');
});
